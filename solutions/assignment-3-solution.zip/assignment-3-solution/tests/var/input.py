print(input_int())
