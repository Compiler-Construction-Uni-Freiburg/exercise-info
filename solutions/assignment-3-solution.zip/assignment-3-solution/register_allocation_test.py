from register_allocation import *
from x86_ast import *
from graph import *

fig34 = [
    Instr("movq", [Immediate(1), Variable("v")]),
    Instr("movq", [Immediate(42), Variable("w")]),
    Instr("movq", [Variable("v"), Variable("x")]),
    Instr("addq", [Immediate(7), Variable("x")]),
    Instr("movq", [Variable("x"), Variable("y")]),
    Instr("movq", [Variable("x"), Variable("z")]),
    Instr("addq", [Variable("w"), Variable("z")]),
    Instr("movq", [Variable("y"), Variable("tmp0")]),
    Instr("negq", [Variable("tmp0")]),
    Instr("movq", [Variable("z"), Variable("tmp1")]),
    Instr("addq", [Variable("tmp0"), Variable("tmp1")]),
    Instr("movq", [Variable("tmp1"), Reg("rdi")]),
    Callq("print_int", 1),
]

simple_example = [
    Instr("movq", [Immediate(40), Variable("tmp.0")]),
    Instr("addq", [Immediate(2), Variable("tmp.0")]),
    Instr("movq", [Variable("tmp.0"), Reg("rdi")]),
    Callq("print_int", 1),
]


def test_uncover_live_1():
    output = uncover_live(simple_example)
    assert output == [
        set(),
        {Variable("tmp.0")},
        {Variable("tmp.0")},
        {Reg("rdi")},
        set(),
    ]


def test_uncover_live_2():
    output = uncover_live(fig34)
    assert output == [
        set(),
        {Variable("v")},
        {Variable("w"), Variable("v")},
        {Variable("w"), Variable("x")},
        {Variable("w"), Variable("x")},
        {Variable("y"), Variable("x"), Variable("w")},
        {Variable("y"), Variable("w"), Variable("z")},
        {Variable("z"), Variable("y")},
        {Variable("z"), Variable("tmp0")},
        {Variable("z"), Variable("tmp0")},
        {Variable("tmp1"), Variable("tmp0")},
        {Variable("tmp1")},
        {Reg("rdi")},
        set(),
    ]


g = build_interference(simple_example)


def test_build_interference_1():
    assert not g.has_edge(Reg("rdi"), Reg("r9"))


def test_build_interference_2():
    assert not (g.has_edge(Variable("tmp.0"), Reg("r9")))


def test_build_interference_3():
    assert not g.has_edge(Reg("rdi"), Reg("rdx"))
