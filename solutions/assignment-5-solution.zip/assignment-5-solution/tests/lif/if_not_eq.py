x = 1
print(777 if (not (x == input_int())) else 42)
