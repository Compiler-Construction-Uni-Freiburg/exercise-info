print(42 if (False if not True else True) else 777)
