print(777 if (False and False) else 42)
