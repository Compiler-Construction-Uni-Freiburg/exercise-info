print(777 if 1 == 0 else 2 + (40 if input_int() == 2 else input_int()))
