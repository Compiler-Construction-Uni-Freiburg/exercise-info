print(42 if (True if True else False) else 777)
