x = input_int()
if x > 1:
    if x > 2:
        if x > 3:
            if x > 4:
                print(42)
            else:
                print(0)
        else:
            print(0)
    else:
        print(0)
else:
    print(0)
