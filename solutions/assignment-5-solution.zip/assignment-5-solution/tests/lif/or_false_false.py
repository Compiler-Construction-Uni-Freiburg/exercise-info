print(777 if False or False else 42)
