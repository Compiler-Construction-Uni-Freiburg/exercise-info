print(42 if not False else 777)
