print(42 if input_int() == 1 else 0)
