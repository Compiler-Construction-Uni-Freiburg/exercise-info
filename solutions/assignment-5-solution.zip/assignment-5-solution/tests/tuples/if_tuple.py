if (True, )[0]:
    print(42)
else:
    print(43)
