a = (3, 5)
b = (a, 5, 6)
if len(b) == 3:
    print(42)
else:
    print(0)
