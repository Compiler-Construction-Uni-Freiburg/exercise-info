# Solution for assignment 1
