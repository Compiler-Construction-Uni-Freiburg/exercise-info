from ast import *
import sys
import utils


def contains_input(e):
    match e:
        case BinOp(r1, Add(), r2):
            return contains_input(r1) or contains_input(r2)
        case UnaryOp(USub(), r):
            return contains_input(r)
        case Constant(n):
            return False
        case Name(var):
            return False
        case Call(Name('input_int'), []):
            return True


def pe_neg(r):
    match r:
        case Constant(n):
            return Constant(-n)
        case _:
            return UnaryOp(USub(), r)


def pe_add(r1, r2):
    match(r1, r2):
        case(Constant(n1), Constant(n2)):
            return Constant(n1 + n2)
        case _:
            return BinOp(r1, Add(), r2)


def pe_exp(e, env):
    match e:
        case BinOp(left, Add(), right):
            return pe_add(pe_exp(left, env), pe_exp(right, env))
        case UnaryOp(USub(), v):
            return pe_neg(pe_exp(v, env))
        case Constant(value):
            return e
        case Call(Name('input_int'), []):
            return e
        case Name(var):
            # If env[var] contains an input_int(), replacing
            # Name(var) with env[var] results in two calls to input_int(),
            # changing the programs behaviour (asking for more user input)
            e_env = env[var]
            if (contains_input(e_env)):
                return Name(var)
            return env[var]


def pe_stmt(s, env):
    match s:
        case Expr(Call(Name('print'), [arg])):
            return Expr(Call(Name('print'), [pe_exp(arg, env)])), env
        case Expr(value):
            return Expr(pe_exp(value, env)), env
        case Assign([Name(var)], exp):
            pexp = pe_exp(exp, env)
            env[var] = pexp
            return Assign([Name(var)], pexp), env
        case _:
            return (None, None)


def pe_P_int(p):
    match p:
        case Module(body):
            env = dict()
            new_body = []
            for s in body:
                stmt, env = pe_stmt(s, env)
                new_body.append(stmt)
            return Module(new_body)


if __name__ == "__main__":
    lines = sys.stdin.readlines()
    program = parse(("\n").join(lines))
    print(pe_P_int(program))
