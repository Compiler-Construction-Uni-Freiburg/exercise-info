from ast import *

################################################################################
# repr for classes in the ast module
################################################################################


def str_Module(self):
    return "\n".join([str(s) for s in self.body])


Module.__str__ = str_Module


def repr_Module(self):
    return "Module(" + repr(self.body) + ")"


Module.__repr__ = repr_Module


def str_Expr(self):
    return str(self.value)


Expr.__str__ = str_Expr


def repr_Expr(self):
    return "Expr(" + repr(self.value) + ")"


Expr.__repr__ = repr_Expr


def str_Assign(self):
    return str(self.targets[0]) + " = " + str(self.value)


Assign.__str__ = str_Assign


def repr_Assign(self):
    return "Assign(" + repr(self.targets) + ", " + repr(self.value) + ")"


Assign.__repr__ = repr_Assign


def str_Return(self):
    return "return " + str(self.value)


Return.__str__ = str_Return


def repr_Return(self):
    return "Return(" + repr(self.value) + ")"


Return.__repr__ = repr_Return


def str_Name(self):
    return self.id


Name.__str__ = str_Name


def repr_Name(self):
    return "Name(" + repr(self.id) + ")"


Name.__repr__ = repr_Name


def str_Constant(self):
    return str(self.value)


Constant.__str__ = str_Constant


def repr_Constant(self):
    return "Constant(" + repr(self.value) + ")"


Constant.__repr__ = repr_Constant


def str_Add(self):
    return "+"


Add.__str__ = str_Add


def repr_Add(self):
    return "Add()"


Add.__repr__ = repr_Add


def str_Sub(self):
    return "-"


Sub.__str__ = str_Sub


def repr_Sub(self):
    return "Sub()"


Sub.__repr__ = repr_Sub


def str_And(self):
    return "and"


And.__str__ = str_And


def repr_And(self):
    return "And()"


And.__repr__ = repr_And


def str_Or(self):
    return "or"


Or.__str__ = str_Or


def repr_Or(self):
    return "Or()"


Or.__repr__ = repr_Or


def str_BinOp(self):
    return str(self.left) + " " + str(self.op) + " " + str(self.right)


BinOp.__str__ = str_BinOp


def repr_BinOp(self):
    return (
        "BinOp("
        + repr(self.left)
        + ", "
        + repr(self.op)
        + ", "
        + repr(self.right)
        + ")"
    )


BinOp.__repr__ = repr_BinOp


def repr_BoolOp(self):
    return repr(self.values[0]) + " " + repr(self.op) + " " + repr(self.values[1])


BoolOp.__repr__ = repr_BoolOp


def str_USub(self):
    return "-"


USub.__str__ = str_USub


def repr_USub(self):
    return "USub()"


USub.__repr__ = repr_USub


def str_Not(self):
    return "not"


Not.__str__ = str_Not


def repr_Not(self):
    return "Not()"


Not.__repr__ = repr_Not


def str_UnaryOp(self):
    return str(self.op) + " " + str(self.operand)


UnaryOp.__str__ = str_UnaryOp


def repr_UnaryOp(self):
    return "UnaryOp(" + repr(self.op) + ", " + repr(self.operand) + ")"


UnaryOp.__repr__ = repr_UnaryOp


def str_Call(self):
    return str(self.func) + "(" + ", ".join([str(arg) for arg in self.args]) + ")"


Call.__str__ = str_Call


def repr_Call(self):
    return "Call(" + repr(self.func) + ", " + repr(self.args) + ")"


Call.__repr__ = repr_Call


def str_If(self):
    return (
        "if "
        + str(self.test)
        + ":\n"
        + "  "
        + "\n  ".join([str(s) for s in self.body])
        + "\n"
        + "else:\n"
        + "  "
        + "\n  ".join([str(s) for s in self.orelse])
        + "\n"
    )


If.__str__ = str_If


def repr_If(self):
    return (
        "If("
        + repr(self.test)
        + ", "
        + repr(self.body)
        + ", "
        + repr(self.orelse)
        + ")"
    )


If.__repr__ = repr_If


def str_IfExp(self):
    return (
        "("
        + str(self.body)
        + " if "
        + str(self.test)
        + " else "
        + str(self.orelse)
        + ")"
    )


IfExp.__str__ = str_IfExp


def repr_IfExp(self):
    return (
        "IfExp("
        + repr(self.body)
        + ", "
        + repr(self.test)
        + ", "
        + repr(self.orelse)
        + ")"
    )


IfExp.__repr__ = repr_IfExp


def str_While(self):
    return (
        "while "
        + str(self.test)
        + ":\n"
        + "  "
        + "\n  ".join([str(s) for s in self.body])
        + "\n"
    )


While.__str__ = str_While


def repr_While(self):
    return (
        "While("
        + repr(self.test)
        + ", "
        + repr(self.body)
        + ", "
        + repr(self.orelse)
        + ")"
    )


While.__repr__ = repr_While


def str_Compare(self):
    return str(self.left) + " " + str(self.ops[0]) + " " + str(self.comparators[0])


Compare.__str__ = str_Compare


def repr_Compare(self):
    return (
        "Compare("
        + repr(self.left)
        + ", "
        + repr(self.ops)
        + ", "
        + repr(self.comparators)
        + ")"
    )


Compare.__repr__ = repr_Compare


def str_Eq(self):
    return "=="


Eq.__str__ = str_Eq


def repr_Eq(self):
    return "Eq()"


Eq.__repr__ = repr_Eq


def str_NotEq(self):
    return "!="


NotEq.__str__ = str_NotEq


def repr_NotEq(self):
    return "NotEq()"


NotEq.__repr__ = repr_NotEq


def str_Lt(self):
    return "<"


Lt.__str__ = str_Lt


def repr_Lt(self):
    return "Lt()"


Lt.__repr__ = repr_Lt


def str_LtE(self):
    return "<="


LtE.__str__ = str_Lt


def repr_LtE(self):
    return "LtE()"


LtE.__repr__ = repr_LtE


def str_Gt(self):
    return ">"


Gt.__str__ = str_Gt


def repr_Gt(self):
    return "Gt()"


Gt.__repr__ = repr_Gt


def str_GtE(self):
    return ">="


GtE.__str__ = str_GtE


def repr_GtE(self):
    return "GtE()"


GtE.__repr__ = repr_GtE

