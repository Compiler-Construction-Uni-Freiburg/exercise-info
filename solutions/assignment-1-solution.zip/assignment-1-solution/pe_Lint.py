from ast import *
import sys
import utils


def pe_neg(r):
    match r:
        case Constant(n):
            return Constant(-n)
        case BinOp(r1, Add(), r2):
            return BinOp(pe_neg(r1), Add(), pe_neg(r2))
        case UnaryOp(USub(), r):
            return r
        case _:
            return UnaryOp(USub(), r)


def pe_add(r1, r2):
    match(r1, r2):
        case(Constant(n1), Constant(n2)):
            return Constant(n1 + n2)
        case(Constant(n1), BinOp(Constant(n2), Add(), r3)):
            return BinOp(Constant(n1 + n2), Add(), r3)
        case(Constant(n1), r2):
            return BinOp(Constant(n1), Add(), r2)
        case(BinOp(Constant(n1), Add(), r3), Constant(n2)):
            return BinOp(Constant(n1 + n2), Add(), r3)
        case(BinOp(Constant(n1), Add(), r3), BinOp(Constant(n2), Add(), r4)):
            return BinOp(Constant(n1 + n2), Add(), BinOp(r3, Add(), r4))
        case(BinOp(Constant(n1), Add(), r3), r4):
            return BinOp(Constant(n1), Add(), BinOp(r3, Add(), r4))
        case(r1, BinOp(Constant(n1), Add(), r2)):
            return BinOp(Constant(n1), Add(), BinOp(r1, Add(), r2))
        case(_, _):
            return BinOp(r2, Add(), r1)


def pe_exp(e):
    match e:
        case BinOp(e1, Add(), e2):
            return pe_add(pe_exp(e1), pe_exp(e2))
        case UnaryOp(USub(), e):
            return pe_neg(pe_exp(e))
        case Constant(n):
            return e
        case Call(Name('input_int'), []):
            return e


def pe_stmt(s):
    match s:
        case Expr(Call(Name('print'), [arg])):
            return Expr(Call(Name('print'), [pe_exp(arg)]))
        case Expr(value):
            return Expr(pe_exp(value))


def pe_P_int(p):
    match p:
        case Module(body):
            new_body = [pe_stmt(s) for s in body]
            return Module(new_body)


if __name__ == "__main__":
    lines = sys.stdin.readlines()
    program = parse(("\n").join(lines))
    print(pe_P_int(program))
