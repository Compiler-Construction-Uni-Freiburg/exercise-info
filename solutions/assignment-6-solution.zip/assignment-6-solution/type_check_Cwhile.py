from type_check_Cif import TypeCheckCif

class TypeCheckCwhile(TypeCheckCif):
    pass
