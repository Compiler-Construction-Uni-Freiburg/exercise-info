print(42 if (input_int() - 2) <= (input_int() + 2) else 0)
