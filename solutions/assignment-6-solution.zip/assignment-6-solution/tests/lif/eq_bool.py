print(42 if False == False else 777)
