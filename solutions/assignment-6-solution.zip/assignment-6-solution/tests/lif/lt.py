print(42 if 1 < 2 else 0)
