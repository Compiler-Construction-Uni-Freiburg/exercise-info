print(10 + 32 if (input_int() == 0 if input_int() == 1 else False) \
      else 700 + 77)
