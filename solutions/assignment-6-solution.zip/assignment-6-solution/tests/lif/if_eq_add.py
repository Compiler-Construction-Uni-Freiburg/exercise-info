print(777 if 1 == 0 else 2 + (40 if (1 + 1) == 2 else 775))
