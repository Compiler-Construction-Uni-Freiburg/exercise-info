print(777 if (True and False) else 42)
