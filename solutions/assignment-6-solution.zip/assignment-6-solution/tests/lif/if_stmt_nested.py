x = input_int()
if not (x == 1):
    if x == 0:
        y = 42
    else:
        y = 777
else:
    y = 0
print(y)
