print(input_int() if 0 == input_int() else 777)
