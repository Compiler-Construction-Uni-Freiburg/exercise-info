a = 1
b = 2
x = -a if input_int() == 0 else b
print(x + 10)
