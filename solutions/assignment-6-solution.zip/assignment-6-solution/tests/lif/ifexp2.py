print(0 if False else 42)
