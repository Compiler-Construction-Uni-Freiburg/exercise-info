x = input_int()
y = input_int()
z = x == y
print(42 if z else 0)
