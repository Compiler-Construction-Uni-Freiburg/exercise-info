print(42 if (True and True) else 777)
