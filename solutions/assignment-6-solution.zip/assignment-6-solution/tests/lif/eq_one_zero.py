print(777 if 1 == 0 else 42)
