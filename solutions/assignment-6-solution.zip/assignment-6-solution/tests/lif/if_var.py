x = True
print(42 if x else 0)
