x = True
if x:
    y = 0
    y = 42
else:
    y = 42
    y = 0
print(y)
