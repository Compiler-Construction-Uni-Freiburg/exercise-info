x = input_int()
y = input_int()
if (x == 0):
    if (y == 1):
        print(42 - 3 + (- 3) + 6)
    else:
        print(41 - 5 - 6 - 7)
else:
    x = 10
    y = 20
    z = 30
    a = 10
    b = 20
    c = 30
    d = 40
    e = 50
    f = 60
    g = -30 if x == 10 else 10
    h = 10
    print(x + y + z + a + b + c + d + e + f + g + h)
