print(42 if 2 >= 1 else 0)
