x = input_int()
if x == 0:
    y = 0
else:
    y = 42
print(y)
