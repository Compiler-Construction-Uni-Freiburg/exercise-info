print(42 if True or False else 777)
