print(42 if True else 0)
