a = input_int() # 10
b = a + 10
if input_int() == 0:  # 1 == 0
    c = a + 32
else:
    if input_int() == 0: # 0 == 0
        c = b + 22
    else:
        c = a + 20
print(c)
