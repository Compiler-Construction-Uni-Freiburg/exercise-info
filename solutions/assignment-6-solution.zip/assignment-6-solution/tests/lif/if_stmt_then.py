x = input_int()
if x == 0:
    y = 42
else:
    y = 0
print(y)
