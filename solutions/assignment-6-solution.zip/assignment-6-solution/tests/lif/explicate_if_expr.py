(30 if True else 40)
