x = input_int()
y = x + 1
z = y + 1
if x == 0:
    print(x)
else:
    print(y)
print(z)    

