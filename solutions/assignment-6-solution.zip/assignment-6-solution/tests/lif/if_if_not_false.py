print(777 if (False if not False else True) else 42)
