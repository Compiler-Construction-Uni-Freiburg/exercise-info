x = input_int()
y = input_int()
print(42 if x == y else 0)
