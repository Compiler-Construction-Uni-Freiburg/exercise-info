print(42 if False or True else 777)
