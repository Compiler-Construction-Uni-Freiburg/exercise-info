def func(x: tuple[int, int]) -> int:
    return x[0]

print(func((42, 0)))
