a = 10
b = 10
c = 10
d = 10
e = 10
f = 10
g = 10
h = 10
i = 10
j = 10
k = 10
l = 10
m = 10
n = 10
o = 10
p = 10
print(a + b + c + d + e + f + g + h + i + j + k + l + m + n + o + p)
