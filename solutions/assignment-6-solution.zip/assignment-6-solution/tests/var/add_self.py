x = 3
x = x + x
print(x)
