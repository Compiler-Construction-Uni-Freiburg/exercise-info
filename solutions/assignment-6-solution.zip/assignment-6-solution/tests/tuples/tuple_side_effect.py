(input_int(),)
