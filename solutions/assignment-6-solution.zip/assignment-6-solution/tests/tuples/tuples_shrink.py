a = (True or False, 32)
print(a[1])

