x = (3, 4, True)
if x[2]:
    print(42)
else:
    print(0)
