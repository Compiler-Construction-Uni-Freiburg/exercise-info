x = (True, input_int())
y = x
if x == y:
    print(42)
else:
    print(0)
