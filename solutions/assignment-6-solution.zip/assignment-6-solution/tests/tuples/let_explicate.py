((input_int() if (2 + 2) > 3 else 0) if 1 > 0 else 0)
