print(50-8)
