x = 3
x = x - 6
print(x)
y = 5
y = 6 - y
print(y)
