x = 3
y = 3
z = x + y
print(z)
