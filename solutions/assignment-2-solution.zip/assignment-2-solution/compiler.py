import ast
from ast import *
from utils import *
from x86_ast import *
import os
from typing import Set
from dataclasses import dataclass
import platform

Binding = tuple[Name, expr]
Temporaries = list[Binding]

get_fresh_tmp = lambda: generate_name("tmp")

@dataclass
class Compiler:
    stack_space: int = 0

    ############################################################################
    # Remove Complex Operands
    ############################################################################

    def tmps_to_stmts(self, tmps: Temporaries) -> list[stmt]:
        return [Assign([tmp[0]], tmp[1]) for tmp in tmps]

    def rco_exp(self, e: expr, need_atomic: bool) -> tuple[expr, Temporaries]:
        match e:
            case Name(var):
                return (Name(var), [])
            case Constant(_):
                return (e, [])
            case Call(Name('input_int'), []):
                if need_atomic:
                    fresh_tmp = get_fresh_tmp()
                    return (Name(fresh_tmp), [(Name(fresh_tmp), e)])
                return (e, [])
            case UnaryOp(USub(), e1):
                atm, tmps = self.rco_exp(e1, True)
                if need_atomic:
                    fresh_tmp = get_fresh_tmp()
                    return (Name(fresh_tmp), tmps + [(Name(fresh_tmp), UnaryOp(USub(), atm))])
                return (UnaryOp(USub(), atm), tmps)
            case BinOp(e1, op, e2):
                atm1, tmps1 = self.rco_exp(e1, True)
                atm2, tmps2 = self.rco_exp(e2, True)
                if need_atomic:
                    fresh_tmp = get_fresh_tmp()
                    return (Name(fresh_tmp), tmps1 + tmps2 + [(Name(fresh_tmp), BinOp(atm1, op, atm2))])
                return (BinOp(atm1, op, atm2), tmps1 + tmps2)

    def rco_stmt(self, s: stmt) -> list[stmt]:
        match s:
            case Expr(Call(Name('print'), [e])):
                atm, tmps = self.rco_exp(e, True)
                return self.tmps_to_stmts(tmps) + [Expr(Call(Name('print'), [atm]))]
            case Expr(e):
                atm, tmps = self.rco_exp(e, False)
                return self.tmps_to_stmts(tmps) + [Expr(atm)]
            case Assign([Name(var)], e):
                atm, tmps = self.rco_exp(e, False)
                return self.tmps_to_stmts(tmps) + [Assign([Name(var)], atm)]

    def remove_complex_operands(self, p: Module) -> Module:
        match p:
            case Module(body):
                new_body = []
                for s in body:
                    new_body += self.rco_stmt(s)
                return Module(new_body)

    ############################################################################
    # Select Instructions
    ############################################################################

    def select_arg(self, e: expr) -> arg:
        match e:
            case Constant(n):
                return Immediate(n)
            case Name(var):
                return Variable(var)

    def select_stmt(self, s: stmt) -> list[instr]:
        match s:
            case Assign([Name(var)], BinOp(atm1, Sub(), atm2)):
                arg1 = self.select_arg(atm1)
                arg2 = self.select_arg(atm2)
                match (arg1, arg2):
                    case (Variable(var2), _):
                        if var == var2:
                            return [Instr("subq", [arg2, Variable(var)])]
                    case (_, Variable(var2)):
                        if var == var2:
                            return [Instr("negq", [Variable(var2)]), Instr("addq", [arg1, Variable(var2)])]
                return [Instr("movq", [arg1, Variable(var)]), Instr("subq", [arg2, Variable(var)])]
            case Assign([Name(var)], BinOp(atm1, Add(), atm2)):
                arg1 = self.select_arg(atm1)
                arg2 = self.select_arg(atm2)
                match (arg1, arg2):
                    case (Variable(var2), _):
                        if var == var2:
                            return [Instr("addq", [arg2, Variable(var)])]
                    case (_, Variable(var2)):
                        if var == var2:
                            return [Instr("addq", [arg1, Variable(var)])]
                return [Instr("movq", [arg1, Variable(var)]), Instr("addq", [arg2, Variable(var)])]
            case Assign([Name(var)], UnaryOp(USub(), atm)):
                arg = self.select_arg(atm)
                return [Instr("movq", [arg, Variable(var)]), Instr("negq", [Variable(var)])]
            case Assign([Name(var)], Call(Name("input_int"), [])):
                return [Callq(label_name("read_int"), 0), Instr("movq", [Reg("rax"), Variable(var)])]
            case Assign([Name(var)], atm):
                arg = self.select_arg(atm)
                return [Instr("movq", [arg, Variable(var)])]
            case Expr(Call(Name("print"), [atm])):
                arg = self.select_arg(atm)
                return [Instr("movq", [arg, Reg("rdi")]), Callq(label_name("print_int"), 1)]
            case Expr(Call(Name("input_int"), [])):
                return [Callq(label_name("read_int"), 0)]

    def select_instructions(self, p: Module) -> X86Program:
        match p:
            case Module(body):
                output = []
                for stm in body:
                    output += self.select_stmt(stm)
                return X86Program(output)
        return X86Program([])

    ############################################################################
    # Assign Homes
    ############################################################################

    def assign_homes_arg(self, a: arg, home: dict[Variable, arg]) -> arg:
        match a:
            case Variable(_):
                if a not in home:
                    self.stack_space += 8
                    home[a] = Deref("rbp", -self.stack_space)
                return home[a]
            case _:
                return a

    def assign_homes_instr(self, i: instr, home: dict[Variable, arg]) -> instr:
        match i:
            case Instr(istr, [arg1, arg2]):
                return Instr(istr, [self.assign_homes_arg(arg1, home),
                                    self.assign_homes_arg(arg2, home)])
            case Instr(istr, [arg1]):
                return Instr(istr, [self.assign_homes_arg(arg1, home)])
            case Callq("read_int", 0):
                return i
            case Callq("print_int", 1):
                return i

    def assign_homes_instrs(
        self, ss: list[instr], home: dict[Variable, arg]
    ) -> list[instr]:
        return [self.assign_homes_instr(istr, home) for istr in ss]

    def assign_homes(self, p: X86Program) -> X86Program:
        self.stack_space = 0
        home : dict[Variable, arg] = dict()
        return X86Program(self.assign_homes_instrs(p.body, home))

    ############################################################################
    # Patch Instructions
    ############################################################################

    def patch_instr(self, i: instr) -> list[instr]:
        match i:
            case Instr(istr, [Deref(reg, offset), Deref(reg2, offset2)]):
                return [Instr("movq", [Deref(reg, offset), Reg("rax")]),
                        Instr(istr, [Reg("rax"), Deref(reg2, offset2)])]
            case _:
                return [i]

    def patch_instrs(self, ss: list[instr]) -> list[instr]:
        output = []
        for s in ss:
            output += self.patch_instr(s)
        return output

    def patch_instructions(self, p: X86Program) -> X86Program:
        return X86Program(self.patch_instrs(p.body))

    ############################################################################
    # Prelude & Conclusion
    ############################################################################

    def prelude_and_conclusion(self, p: X86Program) -> X86Program:
        stack_space_mod16 = self.stack_space if self.stack_space % 16 == 0 else self.stack_space + 8
        prologue = [Instr("pushq", [Reg("rbp")]), Instr("movq", [Reg("rsp"), Reg("rbp")])]
        if stack_space_mod16 > 0:
            prologue.append(Instr("subq", [Immediate(stack_space_mod16), Reg("rsp")]))
        epilogue = [Instr("popq", [Reg("rbp")]), Instr("retq", [])]
        if stack_space_mod16 > 0:
            epilogue.insert(0, Instr("addq", [Immediate(stack_space_mod16), Reg("rsp")]))
        return X86Program(prologue + p.body + epilogue)
